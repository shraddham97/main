package com.infy.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.MobileDTO;
import com.infy.entity.Mobile;
import com.infy.repository.MobileRepository;

@Service(value="mobileService")
@Transactional
public class MobileServiceImpl implements MobileService {
	
	@Autowired
	private MobileRepository mobileRepository;

	@Override
	public List<MobileDTO> getMobileDetails() throws Exception {
		Iterable<Mobile> mobiles = mobileRepository.findAll();
		List<MobileDTO> mobileDTOs = new ArrayList<>();
		mobiles.forEach(mobile -> {
			MobileDTO mobileDto = new MobileDTO();
			mobileDto.setMobileId(mobile.getMobileId());
			mobileDto.setModelName(mobile.getModelName());
			mobileDto.setCompanyName(mobile.getCompanyName());
			mobileDto.setPrice(mobile.getPrice());
			mobileDto.setOs(mobile.getOs());
			mobileDto.setRam(mobile.getRam());
			mobileDTOs.add(mobileDto);
		});
		if (mobileDTOs.isEmpty())
			throw new Exception("Service.CUSTOMERS_NOT_FOUND");
		return mobileDTOs;
	}
	

}
