package com.infy.service;

import java.util.List;

import com.infy.dto.CustomerDTO;

public interface CustomerService {
	
	public CustomerDTO getCustomer(Integer customerId) throws Exception;
	public List<CustomerDTO> getCustomerDetails() throws Exception;
}
