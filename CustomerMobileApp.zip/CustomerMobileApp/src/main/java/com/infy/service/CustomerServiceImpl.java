package com.infy.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.infy.dto.CustomerDTO;
import com.infy.dto.MobileDTO;
import com.infy.entity.Customer;
import com.infy.repository.CustomerRepository;

//DONT MODIFY NAME OF CLASS
//DONT ADD/MODIFY/DELETE/COMMENT ANY METHOD
//DONT DELETE/MODIFY INSTANCE VARIABLE(IF PRESENT)
//DONT MODIFY ANNOTATIONS(IF PRESENT)

public class CustomerServiceImpl implements CustomerService {
	@Autowired
	private CustomerRepository customerRespository;
	@Override
	public CustomerDTO getCustomer(Integer customerId) throws Exception {
		Optional<Customer> optional = customerRespository.findById(customerId);
		Customer customer = optional.orElseThrow(() -> new Exception("Service.CUSTOMER_NOT_FOUND"));
		CustomerDTO customerDto = new CustomerDTO();
		customerDto.setCustomerId(customer.getCustomerId());
		customerDto.setCustomerName(customer.getCustomerName());
		customerDto.setAddress(customer.getAddress());
		
		MobileDTO mobiledto=new MobileDTO();
		mobiledto.setMobileId(customer.getMobile().getMobileId());
		mobiledto.setCompanyName(customer.getMobile().getCompanyName());
		mobiledto.setModelName(customer.getMobile().getModelName());
		mobiledto.setRam(customer.getMobile().getRam());
		mobiledto.setOs(customer.getMobile().getOs());
		mobiledto.setPrice(customer.getMobile().getPrice());
		customerDto.setMobile(mobiledto);
		return customerDto;
	}

	@Override
	public List<CustomerDTO> getCustomerDetails() throws Exception {
		Iterable<Customer> customers = customerRespository.findAll();
		List<CustomerDTO> customerDTOs = new ArrayList<>();
		customers.forEach(customer -> {
			CustomerDTO customerDto = new CustomerDTO();
			customerDto.setCustomerId(customer.getCustomerId());
			customerDto.setCustomerName(customer.getCustomerName());
			customerDto.setAddress(customer.getAddress());
			
			MobileDTO mobiledto=new MobileDTO();
			mobiledto.setMobileId(customer.getMobile().getMobileId());
			mobiledto.setCompanyName(customer.getMobile().getCompanyName());
			mobiledto.setModelName(customer.getMobile().getModelName());
			mobiledto.setRam(customer.getMobile().getRam());
			mobiledto.setOs(customer.getMobile().getOs());
			mobiledto.setPrice(customer.getMobile().getPrice());
			customerDto.setMobile(mobiledto);
			customerDTOs.add(customerDto);
		});
		if (customerDTOs.isEmpty())
			throw new Exception("Service.CUSTOMERS_NOT_FOUND");
		return customerDTOs;
	}

	

}
