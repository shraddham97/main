package com.infy.dto;

public class CustomerDTO {
	private Integer customerId;
	private String customerName;
	private String address;
	
	private MobileDTO mobile;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public MobileDTO getMobile() {
		return mobile;
	}

	public void setMobile(MobileDTO mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "CustomerDTO [customerId=" + customerId + ", customerName=" + customerName + ", address=" + address
				+ ", mobile=" + mobile + "]";
	}

	

}