CREATE DATABASE IF NOT EXISTS CustomerMobileDB;
USE CustomerMobileDB;
DROP TABLE IF EXISTS Customer;
DROP TABLE IF EXISTS Mobile;

create table Mobile(
mobile_id INT(10)  primary key,
company_name varchar(25) not null,
model_name varchar(25) not null,
ram varchar(10) not null,
os varchar(25) not null,
price int(5) not null
);

insert into Mobile values(111,'oneplus','7T','8gb','oxygen os',40000);
insert into Mobile values(222,'iphone','11 pro','4gb','iOS 13',99900);
insert into Mobile values(333,'microsoft','lumia 950 xl','3gb','microsodft windows 10',16000);


create table Customer(
customer_id int(4) primary key,
name varchar(25) not null,
address varchar(30) not null,
mobile_id int(16) references Mobile(mobile_id) 
); 

insert into Customer values(2001,'Markel','mysore',111);
insert into Customer values(2002,'Chris', 'bangalore',222);
insert into Customer values(2003,'James', 'udupi',333);


select * from Customer;

select * from Mobile;


	